CARA DEPLOY KE VERCEL

Struktur:
- index.html
- api/send.js
- package.json

1. Upload folder/project ini ke GitHub atau langsung import ke Vercel.

2. Di Vercel buka:
   Project -> Settings -> Environment Variables

3. Tambahkan:
   TELEGRAM_BOT_TOKEN = TOKEN BOT BARU KAMU
   TELEGRAM_CHAT_ID = ID CHAT TUJUAN

4. Centang environment yang digunakan (Production, dan Preview jika perlu).

5. Redeploy project setelah environment variable dibuat.

6. Website akan mengirim:
   Browser -> /api/send -> Telegram

Token bot tidak lagi ada di index.html.

PENTING:
Token bot yang pernah ditaruh di HTML publik sebaiknya diregenerate/revoke melalui BotFather. Jangan masukkan token baru ke index.html.
