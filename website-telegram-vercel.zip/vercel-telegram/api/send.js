import formidable from 'formidable';
import fs from 'node:fs/promises';

export const config = {
  api: {
    bodyParser: false,
  },
};

const MAX_FILE_SIZE = 10 * 1024 * 1024;
const TELEGRAM_MAX_CAPTION = 1024;

function getField(fields, name) {
  const value = fields?.[name];
  if (Array.isArray(value)) return value[0] ?? '';
  return value ?? '';
}

function getFile(files, name) {
  const value = files?.[name];
  if (Array.isArray(value)) return value[0];
  return value;
}

export default async function handler(req, res) {
  if (req.method !== 'POST') {
    res.setHeader('Allow', 'POST');
    return res.status(405).json({ ok: false, error: 'Method tidak diizinkan.' });
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    console.error('Environment variables Telegram belum diatur.');
    return res.status(500).json({
      ok: false,
      error: 'Konfigurasi server belum lengkap.'
    });
  }

  try {
    const form = formidable({
      multiples: false,
      maxFiles: 1,
      maxFileSize: MAX_FILE_SIZE,
      allowEmptyFiles: false,
      filter: ({ mimetype }) => Boolean(mimetype?.startsWith('image/')),
    });

    const [fields, files] = await form.parse(req);
    const message = String(getField(fields, 'message')).trim();
    const photo = getFile(files, 'photo');

    if (!message && !photo) {
      return res.status(400).json({
        ok: false,
        error: 'Tulis pesan atau pilih foto dulu ya.'
      });
    }

    const telegramUrl = `https://api.telegram.org/bot${token}`;

    if (photo) {
      const buffer = await fs.readFile(photo.filepath);
      const filename = photo.originalFilename || 'foto.jpg';
      const mimeType = photo.mimetype || 'image/jpeg';

      let caption = `💌 PESAN DARI WEBSITE\n\n${message || '(Tidak ada pesan teks)'}\n\n📸 Ada foto yang ikut dikirim.\n\n━━━━━━━━━━━━━━\n🌷 dikirim dari halaman kecil`;

      // Telegram membatasi caption foto. Potong dengan aman jika terlalu panjang.
      if (caption.length > TELEGRAM_MAX_CAPTION) {
        caption = caption.slice(0, TELEGRAM_MAX_CAPTION - 3) + '...';
      }

      const telegramForm = new FormData();
      telegramForm.append('chat_id', chatId);
      telegramForm.append(
        'photo',
        new Blob([buffer], { type: mimeType }),
        filename
      );
      telegramForm.append('caption', caption);

      const response = await fetch(`${telegramUrl}/sendPhoto`, {
        method: 'POST',
        body: telegramForm,
      });

      const data = await response.json();

      if (!response.ok || !data.ok) {
        console.error('Telegram sendPhoto:', data);
        return res.status(502).json({
          ok: false,
          error: data.description || 'Telegram gagal menerima foto.'
        });
      }
    } else {
      const text = `💌 PESAN DARI WEBSITE\n\nSeseorang meninggalkan pesan:\n\n"${message}"\n\n━━━━━━━━━━━━━━\n🌷 dikirim dari halaman kecil`;

      const response = await fetch(`${telegramUrl}/sendMessage`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          chat_id: chatId,
          text,
        }),
      });

      const data = await response.json();

      if (!response.ok || !data.ok) {
        console.error('Telegram sendMessage:', data);
        return res.status(502).json({
          ok: false,
          error: data.description || 'Telegram gagal menerima pesan.'
        });
      }
    }

    return res.status(200).json({ ok: true });
  } catch (error) {
    console.error('API /api/send error:', error);

    return res.status(500).json({
      ok: false,
      error: 'Terjadi kesalahan pada server saat mengirim.'
    });
  }
}
